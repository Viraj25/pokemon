import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-addpokemonpopup',
  templateUrl: './addpokemonpopup.component.html',
  styleUrls: ['./addpokemonpopup.component.scss'],
})
export class AddpokemonpopupComponent implements OnInit {
  @Input() buttonClick: Boolean = false;
  constructor() {}

  ngOnInit(): void {}
  submitPokemonData() {
    this.buttonClick = false;
    alert('submit');
  }
}
