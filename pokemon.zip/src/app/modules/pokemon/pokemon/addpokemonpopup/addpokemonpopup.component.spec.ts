import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddpokemonpopupComponent } from './addpokemonpopup.component';

describe('AddpokemonpopupComponent', () => {
  let component: AddpokemonpopupComponent;
  let fixture: ComponentFixture<AddpokemonpopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddpokemonpopupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddpokemonpopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
