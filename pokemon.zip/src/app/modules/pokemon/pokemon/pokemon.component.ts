import { Component, OnInit } from '@angular/core';
import { AddpokemonpopupComponent } from './addpokemonpopup/addpokemonpopup.component';
import { PokemonserviceService } from './pokemonservice.service';
import { IpokemonType } from './interfacepokemon';
import { FormBuilder, FormGroup } from '@angular/forms';
import { pokemondataobj } from './pokemondata.model';

const ELEMENT_DATA: IpokemonType[] = [];
@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon.component.html',
  styleUrls: ['./pokemon.component.scss'],
})
export class PokemonComponent implements OnInit {
  buttonClick = false;
  pokeData: IpokemonType[] = [];
  pokemondata: IpokemonType[] = [];
  // pokemonsdatas: any;

  columnsToDisplay: string[] = [
    'name',
    'level',
    'type',
    'dateCreated',
    'dateUpdated',
    'editBtnColumn',
    'deleteBtnColumn',
  ];

  formValue!: FormGroup;

  constructor(
    private pokeService: PokemonserviceService,
    private formbuilder: FormBuilder
  ) {}
  // addPopup() {
  //   this.buttonClick = true;
  // }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      name: [''],
      level: [''],
      type: [''],
    });
    this.getPokemonData();
  }

  getPokemonData() {
    this.pokeService.getPokemon().subscribe((response) => {
      this.pokeData = response;
      console.log('pokemon data', response);
      this.pokeData = Object(response).data;
      console.log('pokedata', this.pokeData);
    });
  }
  postPokemonData() {
    // this.pokemondata.name = this.formValue.value.name;
    // this.pokemondata.level = this.formValue.value.level;
    // this.pokemondata.type = this.formValue.value.type;

    // this.pokemondata.type = this.formValue.value.type;

    this.pokeService.postPokemonData(this.pokeData).subscribe((res) => {
      this.pokeData = res.data;
      alert('sucess added');
    });
    alert('updated');
    let ref = document.getElementById('close');
    ref?.click();
    this.formValue.reset();
    this.getPokemonData();
  }
  deletePokemon(pokeData: any) {
    alert('delete');
  }
}
