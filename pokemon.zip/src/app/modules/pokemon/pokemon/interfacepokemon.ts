export interface IpokemonType {
  name: string;

  level: number;
  type: string;
  created: string;
  updated: string;
}
