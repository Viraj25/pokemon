export class pokemondataobj {
  name: string = '';

  level: number = 0;
  type: string = '';
}
