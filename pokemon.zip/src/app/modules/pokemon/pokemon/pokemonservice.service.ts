import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IpokemonType } from './interfacepokemon';
import { map, Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class PokemonserviceService {
  constructor(private httpClient: HttpClient) {}
  httpHeader = {
    headers: new HttpHeaders({
      Authorization: this.getToken() || '',
    }),
  };
  getToken() {
    return window.localStorage.getItem('token');
  }

  getPokemon() {
    return this.httpClient.get('http://localhost:3000/pokemon').pipe(
      map((res: any) => {
        return res;
      })
    );
  }
  postPokemonData(data: any) {
    return this.httpClient
      .post<any>('http://localhost:3000/pokemon', data)
      .pipe(
        map((res: any) => {
          return res;
        })
      );
  }
}
