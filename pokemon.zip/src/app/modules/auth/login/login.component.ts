import { Component, Input, OnInit } from '@angular/core';

import { AuthserviceService } from '../authservices/authservice.service';
import {
  FormGroup,
  FormControl,
  FormControlName,
  Validators,
  FormBuilder,
} from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  email = 'xxxx@gmail.com';
  password = 'xxxxxxxx';

  constructor(
    private authervice: AuthserviceService,
    private router: Router,
    private formbuilder: FormBuilder
  ) {}

  ngOnInit(): void {}

  loginForm = this.formbuilder.group({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [
      Validators.required,
      Validators.minLength(4),
    ]),
  });

  get Email() {
    return this.loginForm.get('email');
  }

  get Password() {
    return this.loginForm.get('password');
  }

  onSubmit(loginForm: FormGroup) {
    this.authervice.loginData(loginForm.value).subscribe((res) => {
      localStorage.setItem('token', Object(res).data.token);
      alert('login succesfully');
      console.log(res);
    });
    if (localStorage.getItem('token')) {
      this.router.navigateByUrl('/pokemon');
    }
  }
}
