import { ButtonHostDirective } from './button-host.directive';

describe('ButtonHostDirective', () => {
  it('should create an instance', () => {
    const directive = new ButtonHostDirective();
    expect(directive).toBeTruthy();
  });
});
