import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';

import { InputComponent } from './input/input.component';
import { ButtonComponent } from './button/button.component';
import { ButtonHostDirective } from './directive-button/button-host.directive';
@NgModule({
  declarations: [InputComponent, ButtonComponent, ButtonHostDirective],
  imports: [CommonModule, FormsModule, MatButtonModule],
  exports: [InputComponent, ButtonComponent, ButtonHostDirective],
})
export class SharedModule {}
