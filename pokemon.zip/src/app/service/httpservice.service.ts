import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DataLogin } from '../interface';

@Injectable({
  providedIn: 'root',
})
export class HttpserviceService {
  accesToken: string = '';
  baseUrl = 'http://localhost:3000';

  constructor(private httpservice: HttpClient) {}

  loginData(logindata: DataLogin): Observable<DataLogin> {
    console.log(logindata);
    return this.httpservice.post<DataLogin>(
      `${this.baseUrl}/auth/login`,
      logindata
    );
  }

  getToken() {
    return localStorage.getItem('token');
  }
}
