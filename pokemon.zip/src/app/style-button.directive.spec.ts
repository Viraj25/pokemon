import { StyleButtonDirective } from './style-button.directive';

describe('StyleButtonDirective', () => {
  it('should create an instance', () => {
    const directive = new StyleButtonDirective();
    expect(directive).toBeTruthy();
  });
});
