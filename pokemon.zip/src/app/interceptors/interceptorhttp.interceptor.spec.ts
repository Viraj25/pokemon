import { TestBed } from '@angular/core/testing';

describe('InterceptorhttpInterceptor', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      providers: [],
    })
  );
});
