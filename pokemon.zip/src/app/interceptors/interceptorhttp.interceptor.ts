import { Injectable } from '@angular/core';
import { AuthserviceService } from '../modules/auth/authservices/authservice.service';
import { Injector } from '@angular/core';
import {
  HttpEvent,
  HttpEventType,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
} from '@angular/common/http';
import { tap } from 'rxjs';
import { DataLogin } from '../interface';

@Injectable({
  providedIn: 'root',
})
export class InterceptorService implements HttpInterceptor {
  constructor() {}

  intercept(req: HttpRequest<DataLogin>, next: HttpHandler) {
    const token: string = localStorage.getItem('token') || '';
    let tokenReq = req.clone({
      setHeaders: {
        Authorization: token,
      },
    });

    return next.handle(tokenReq).pipe(
      tap((event) => {
        console.log(event);
        if (event.type === HttpEventType.Response) {
          if (event.status === 200) {
            console.log('Logged In successfully');
          }
        }
      })
    );
  }
}
