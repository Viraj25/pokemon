export interface DataLogin {
  email: string;
  password: string;
}
